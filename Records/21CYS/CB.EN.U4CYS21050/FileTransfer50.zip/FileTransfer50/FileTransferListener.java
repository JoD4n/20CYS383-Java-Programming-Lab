package com.amrita.jpl.cys21050.pract;

interface FileTransferListener {
    void onFileSent(String filename);

    void onFileSaved(String filename);
}
